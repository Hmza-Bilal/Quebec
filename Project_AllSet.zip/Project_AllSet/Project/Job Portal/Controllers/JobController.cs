﻿using Job_Portal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;
using System.Collections.Specialized;

namespace Job_Portal.Controllers
{
    public class JobController : Controller
    {
        public ProjectContext dbcontext = new ProjectContext();
        private bool IsAuthorized()
        {
            if (HttpContext.Request.Cookies["Role"] == "Recruiter")
            {
                return true;
            }
            return false;
        }
        private bool isValidUser()
        {
            if (HttpContext.Request.Cookies.ContainsKey("Email"))
            {
                return true;
            }
            return false;
        }
        public IActionResult Index()
        {
            if(isValidUser())
            {
                JobRepository jobrepo = new JobRepository();
                var jobs = jobrepo.GetJobs();
                return View(jobs);
            }
            return RedirectToAction("Login", "User", new { area = "" });
        }
        public IActionResult New()
        {
            if (IsAuthorized())
            {
                return View();
            }
            return RedirectToAction("Index");
        }
        public IActionResult Save(Job j)
        {
            // Saving Job Code
            if (IsAuthorized())
            {
                JobRepository jobrepo = new JobRepository();
                jobrepo.SaveJob(j);
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
        public IActionResult Edit(int id)
        {
            if (IsAuthorized())
            {
                Job j = dbcontext.Jobs.Where(a => a.Id == id).Single();
                return View(j);
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Edit(Job j)
        {
            ProjectContext context = new ProjectContext();
            if (IsAuthorized())
            {
                JobRepository jobrepo = new JobRepository();
                jobrepo.UpdateJob(j);
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
        public IActionResult Delete(Job j)
        {
            if (IsAuthorized())
            {
                JobRepository jobrepo = new JobRepository();
                jobrepo.DeleteJob(j);
            }
            return RedirectToAction("Index");
        }
    }
}
