﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Job_Portal.Models;
using System.Reflection.Metadata;

namespace Job_Portal.Controllers
{
    public class UserController : Controller
    {
        private readonly IWebHostEnvironment Environment;
        public UserController(IWebHostEnvironment environment)
        {
            Environment = environment;
        }
        private bool isAlreadyLoggedIn()
        {
            if (HttpContext.Request.Cookies.ContainsKey("Email"))
            {
                return true;
            }
            return false;
        }
        public IActionResult Signup()
        {
            if (isAlreadyLoggedIn())
            {
                return RedirectToAction("Index", "Job", new { area = "" });
            }
            return View();
        }
        public IActionResult Save(User u)
        {
            UserRespository ur = new UserRespository();
            ur.SaveUser(u);
            return RedirectToAction("Index","Job" , new { area="" });
        }
        public IActionResult Login()
        {
            if (isAlreadyLoggedIn())
            {
                return RedirectToAction("Index", "Job", new { area = "" });
            }
            return View();
        }
        [HttpPost]
        public IActionResult Login(User us)
        {
            UserRespository ur = new UserRespository();
            User u = ur.FindUser(us.Email, us.Password);
            if (u == null)
            {
                return RedirectToAction("Login");
            }
            else
            {
                HttpContext.Response.Cookies.Append("Email", u.Email);
                HttpContext.Response.Cookies.Append("Role", u.Role);
                HttpContext.Response.Cookies.Append("Image", u.ImageName);
                return RedirectToAction("Index", "Job", new { area = "" });
            }
        }
        public IActionResult Logout()
        {
            HttpContext.Response.Cookies.Delete("Email");
            HttpContext.Response.Cookies.Delete("Role");
            HttpContext.Response.Cookies.Delete("Image");
            return RedirectToAction("Index", "Home", new {area=""});
        }
        [HttpPost]
        public IActionResult UploadImage(List<IFormFile> Images)
        {
            string email = HttpContext.Request.Cookies["Email"];
            string wwwPath = this.Environment.WebRootPath;
            string path = Path.Combine(wwwPath, "Uploads");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            foreach (var file in Images)
            {
                var fileName = Path.GetFileName(file.FileName);
                var pathWithFileName = Path.Combine(path, fileName);
                using (FileStream stream = new
                    FileStream(pathWithFileName,
                    FileMode.Create))
                {
                    file.CopyTo(stream);
                    ViewBag.Message = "file uploaded successfully";
                }
                UserRespository userrepo = new UserRespository();
                userrepo.SaveImage(fileName, email);
                HttpContext.Response.Cookies.Append("Image", fileName);
            }
            return RedirectToAction("Index", "Job", new { area = "" });
        }
    }
}
