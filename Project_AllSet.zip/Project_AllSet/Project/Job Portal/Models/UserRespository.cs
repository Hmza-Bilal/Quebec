﻿using Microsoft.EntityFrameworkCore;

namespace Job_Portal.Models
{
    public class UserRespository
    {
        private ProjectContext dbcontext = new ProjectContext();
        public void SaveUser(User u)
        {
            dbcontext.Users.Add(u);
            dbcontext.SaveChanges();
        }
        public User FindUser(string email , string pass)
        {
            User u;
            try
            {
                u = dbcontext.Users.Where(e => e.Email == email).Where(e => e.Password == pass).Single();
            }catch(Exception ex)
            {
                u = null;
            }
            return u;
        }
        public User FindUserByEmail(string email)
        {
            User u;
            try
            {
                u = dbcontext.Users.Where(e => e.Email == email).Single();
            }
            catch (Exception ex)
            {
                u = null;
            }
            return u;
        }
        public void SaveImage(string filename, string email)
        {
            User user = FindUserByEmail(email);
            user.ImageName = filename;
            dbcontext.SaveChanges();
        }
    }
}
