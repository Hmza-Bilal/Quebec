﻿namespace Job_Portal.Models
{
    public class JobRepository
    {
        public ProjectContext dbcontext = new ProjectContext();
        public List<Job> GetJobs()
        {
            List<Job> jobs = new List<Job>();
            jobs = dbcontext.Jobs.ToList();
            return jobs;
        }
        public int SaveJob(Job j)
        {
            int status;
            try { 
                dbcontext.Jobs.Add(j);
                dbcontext.SaveChanges();
                status = 1;
            }
            catch (Exception ex)
            {
                status = 0;
            }
            return status;
        }
        public Job FindJob(int id)
        {
            Job job;
            try
            {
                job = dbcontext.Jobs.Where(a => a.Id == id).Single();
            }
            catch (Exception ex)
            {
                job = null;
            }
            return job;
        }
        public void UpdateJob(Job j)
        {
            Job job = FindJob(j.Id);
            job.Title = j.Title;
            job.Description = j.Description;
            job.Category = j.Category;
            dbcontext.SaveChanges();
        }
        public void DeleteJob(Job j)
        {
            Job job = FindJob(j.Id);
            dbcontext.Jobs.Remove(job);
            dbcontext.SaveChanges();
        }
    }
}
