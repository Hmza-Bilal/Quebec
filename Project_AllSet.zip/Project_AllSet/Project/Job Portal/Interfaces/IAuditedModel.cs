﻿namespace Job_Portal.Interfaces
{
    public interface IAuditedModel
    {
        public string CreatedByUserEmail { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string UpdatedByUserEmail { get; set; }
    }

}
