﻿using System.Diagnostics.Eventing.Reader;

namespace Job_Portal.Interfaces
{
    public interface IActivableModel
    {
        public bool isActive { get; set; }
    }
}
