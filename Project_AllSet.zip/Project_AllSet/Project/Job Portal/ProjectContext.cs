﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Job_Portal;

public partial class ProjectContext : DbContext
{
    public ProjectContext()
    {
    }

    public ProjectContext(DbContextOptions<ProjectContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Job> Jobs { get; set; }
    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Project;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Job>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Job__3214EC07FF47C46C");

            entity.ToTable("Job");

            entity.Property(e => e.Category)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    public override int SaveChanges()
    {
        ProcessSave();
        return base.SaveChanges();
    }
    private void ProcessSave()
    {
        var currentTime = DateTimeOffset.UtcNow;
        foreach (var entry in ChangeTracker.Entries().Where(e => e.State == EntityState.Added && e.Entity is FullAuditedModel))
        {
            var entity = entry.Entity as FullAuditedModel;
            entity.CreatedAt = DateTime.Now;
            entity.CreatedByUserEmail = "temp@gmail.com";
            entity.UpdatedAt = DateTime.Now;
            entity.UpdatedByUserEmail = "temp@gmail.com";
        }
        foreach (var item in ChangeTracker.Entries().Where(e => e.State == EntityState.Modified && e.Entity is FullAuditedModel))
        {
            var entity = item.Entity as FullAuditedModel;
            entity.UpdatedAt = DateTime.Now;
            entity.UpdatedByUserEmail = "temp@gmail.com";
            item.Property(nameof(entity.CreatedAt)).IsModified = false;
            item.Property(nameof(entity.CreatedByUserEmail)).IsModified = false;
        }
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
