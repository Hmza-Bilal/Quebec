﻿using Job_Portal.Interfaces;

namespace Job_Portal
{
    public abstract class FullAuditedModel : IAuditedModel , IActivableModel
    {
        public string CreatedByUserEmail { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string UpdatedByUserEmail { get; set; }
        public bool isActive { get; set; }
    }
}
